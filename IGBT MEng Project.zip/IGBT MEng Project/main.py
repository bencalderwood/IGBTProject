from igbt_temp_data_logger import collect_temperature_window
from igbt_temperature_feature_extraction import extract_temperature_features
from igbt_temperature_features_to_csv import assign_temperature_health_label
from igbt_temperature_features_to_csv import append_features_to_csv

#import board
#import digitalio
#import adafruit_max31865

# ---------- Temperature Sensor setup (may need to edit to your assigned variables) ----------
# spi = board.SPI()
# cs = digitalio.DigitalInOut(board.D5)
#
# sensor = adafruit_max31865.MAX31865(
#     spi, cs,
#     rtd_nominal=100.0,
#     ref_resistor=430.0,
#     wires=3
# )
#
# ---------- Main loop ----------
t, T = collect_temperature_window(sensor, duration=60, fs=2) #sensor will be correct when you define it with your variables, you may need to create a python file to set up

features = extract_temperature_features(t, T)

health_label = assign_temperature_health_label(features["T_mean"])

append_features_to_csv(
    features,
    label=health_label,
    filename="temperature_RF_dataset.csv"
)

print("Temperature feature window saved.")